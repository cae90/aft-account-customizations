## Audit Manager with Terraform

This is the configuration to enable the Audit Account as Delegated Administrator in BAC. The complementary information will be found in the Audit Account.